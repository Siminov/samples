///
/// [SIMINOV FRAMEWORK]
/// Copyright [2015] [Siminov Software Solution LLP|support@siminov.com]
///
/// Licensed under the Apache License, Version 2.0 (the "License");
/// you may not use this file except in compliance with the License.
/// You may obtain a copy of the License at
///
///     http://www.apache.org/licenses/LICENSE-2.0
///
/// Unless required by applicable law or agreed to in writing, software
/// distributed under the License is distributed on an "AS IS" BASIS,
/// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
/// See the License for the specific language governing permissions and
/// limitations under the License.
///

#import <Foundation/Foundation.h>
#import "SICDatabaseMappingDescriptor.h"

/** Exposes methods to GET and SET Database Descriptor information as per define in DatabaseDescriptor.si.xml file by application.
	
 Example:
	
    <database-descriptor>
	
     <!-- General Database Descriptor Properties -->
     
     <!-- Mandatory Field -->
     <property name="database_name">name_of_database_file</property>
        
     <!-- Optional Field (Default is sqlite)-->
     <property name="type">type_of_database</property>
        
     <!-- Mandatory Field -->
     <property name="version">database_version</property>
     
     <!-- Optional Field -->
     <property name="description">database_description</property>
        
     <!-- Optional Field (Default is false) -->
     <property name="transaction_safe">true/false</property>
     
     <!-- Optional Field (Default is false) -->
     <property name="external_storage">true/false</property>
 
        
     <!-- Database Mapping Descriptor Paths Needed Under This Database Descriptor -->
     
     <!-- Optional Field -->
     <database-mapping-descriptors>
     <database-mapping-descriptor>full_path_of_database_mapping_descriptor_file</database-mapping-descriptor>
     </database-mapping-descriptors>
 
	</database-descriptor>
 */
@interface SICDatabaseDescriptor: NSObject <SICIDescriptor> {

	NSMutableDictionary *properties;
    NSMutableArray *databaseMappingDescriptorPaths;
    
    NSMutableDictionary *databaseMappingDescriptorsBasedOnTableName;
    NSMutableDictionary *databaseMappingDescriptorsBasedOnClassName;
    NSMutableDictionary *databaseMappingDescriptorsBasedOnPath;
}

/**
 * Get database descriptor name as defined in DatabaseDescriptor.core.xml file.
 * @return Database Descriptor Name.
 */
- (NSString *)getDatabaseName;

/**
 * Set database descriptor name as per defined in DatabaseDescriptor.core.xml file.
 * @param databaseName Database Descriptor Name.
 */
- (void)setDatabaseName:(NSString * const)databaseName;

/**
 * Get type of database
 * @return Type of database
 */
- (NSString *)getType;

/**
 * Set type of database
 * @param type Type of database
 */
- (void)setType:(NSString *)type;

/**
 * Get Version of Application as per defined in ApplicationDescriptor.core.xml file.
 * Version of application.
 */
- (double) getVersion;

/**
 * Set Version of Application as per defined in ApplicationDescriptor.core.xml file.
 * @param version Version of application.
 */
- (void)setVersion:(double const)version;

/**
 * Get description as per defined in DatabaseDescriptor.core.xml file.
 * @return Description defined in DatabaseDescriptor.core.xml file.
 */
- (NSString *)getDescription;

/**
 * Set description as per defined in DatabaseDescritor.xml file.
 * @param description Description defined in DatabaseDescriptor.core.xml file.
 */
- (void)setDescription:(NSString * const)description;

/**
 * Check whether database needs to be stored on SDCard or not.
 * @return TRUE:If external_storage defined as true in DatabaseDescriptor.core.xml file, FALSE:If external_storage defined as false in DatabaseDescritor.xml file.
 */
- (BOOL)isExternalStorageEnable;

/**
 * Set the external storage value as per defined in DatabaseDescriptor.si.xml file.
 * @param isExternalStorageEnable (true/false) External Storage Enable Or Not.
 */
- (void)setExternalStorageEnable:(BOOL const) isExternalStorageEnable;

/**
 * Check whether database transactions to make multi-threading safe or not.
 * @return TRUE: If locking is required as per defined in DatabaseDescriptor.si.xml file, FALSE: If locking is not required as per defined in DatabaseDescriptor.si.xml file.
 */
- (BOOL)isTransactionSafe;

/**
 * Set database locking as per defined in DatabaseDescriptor.si.xml file.
 * @param transactionSafe (true/false) database locking as per defined in DatabaseDescriptor.si.xml file.
 */
- (void)setTransactionSafe:(BOOL const) transactionSafe;

/**
 * Check whether database mapping object exists or not, based on table name.
 * @param tableName Name of table.
 * @return TRUE: If database mapping exists, FALSE: If database mapping does not exists.
 */
- (BOOL)containsDatabaseMappingDescriptorBasedOnTableName:(NSString * const)tableName;

/**
 * Check whether database mapping object exists or not, based on POJO class name.
 * @param className POJO class name.
 * @return TRUE: If database mapping exists, FALSE: If database mapping does not exists.
 */
- (BOOL)containsDatabaseMappingDescriptorBasedOnClassName:(NSString * const)className;

/**
 * Get all database mapping paths as per defined in DatabaseDescriptor.core.xml file.
 * @return Iterator which contain all database mapping paths.
 */
- (NSEnumerator *)getDatabaseMappingDescriptorPaths;

/** Add database mapping path as per defined in DatabaseDescriptor.si.xml file.
 
 EXAMPLE:

    <database-descriptor>
    <database-mappings>
    <database-mapping path="Liquor-Mappings/Liquor.xml" />
    <database-mapping path="Liquor-Mappings/LiquorBrand.xml" />
    </database-mappings>
	</database-descriptor>
 
 @param databaseMappingDescriptorPath Database Mapping Path.
 */
- (void)addDatabaseMappingDescriptorPath:(NSString * const)databaseMappingDescriptorPath;

/**
 * Get all database mapping objects contained.
 * @return All database mapping objects.
 */
- (NSEnumerator *)getDatabaseMappingDescriptors;

/**
 * Get database mapping object based on table name.
 * @param tableName Name of table.
 * @return DatabaseMapping object based on table name.
 */
- (SICDatabaseMappingDescriptor *)getDatabseMappingDescriptorBasedOnTableName:(NSString * const)tableName;

/**
 * Get database mapping object based on POJO class name.
 * @param className POJO class name.
 * @return Database Mapping object.
 */
- (SICDatabaseMappingDescriptor *)getDatabseMappingDescriptorBasedOnClassName:(NSString * const)className;

/**
 * Get database mapping object based on path.
 * @param databaseMappingDescriptorPath Database Mapping path as per defined in Database Descriptor.xml file.
 * @return Database Mapping object.
 */
- (SICDatabaseMappingDescriptor *)getDatabseMappingDescriptorBasedOnPath:(NSString * const)databaseMappingDescriptorPath;

/**
 * Add database mapping object in respect to database mapping path.
 * @param databaseMappingDescriptorPath Database Mapping Path.
 * @param databaseMappingDescriptor Database Mapping object.
 */
- (void)addDatabaseMappingDescriptor:(NSString * const)databaseMappingDescriptorPath databaseMappingDescriptor:(SICDatabaseMappingDescriptor *)databaseMappingDescriptor;

/**
 * Remove database mapping object based on database mapping path.
 * @param databaseMappingDescriptorPath Database Mapping Path.
 */
- (void)removeDatabaseMappingDescriptorBasedOnPath:(NSString * const)databaseMappingDescriptorPath;

/**
 * Remove database mappping object based on POJO class name.
 * @param className POJO class name.
 */
- (void)removeDatabaseMappingDescriptorBasedOnClassName:(NSString * const)className;

/**
 * Remove database mapping object based on table name.
 * @param tableName Name of table.
 */
- (void)removeDatabaseMappingDescriptorBasedOnTableName:(NSString * const)tableName;

/**
 * Remove database mapping object based on database mapping object.
 * @param databaseMappingDescriptor Database Mapping object which needs to be removed.
 */
- (void)removeDatabaseMappingDescriptor:(SICDatabaseMappingDescriptor * const)databaseMappingDescriptor;

/**
 * Get all database mapping objects in sorted order. The order will be as per defined in DatabaseDescriptor.core.xml file.
 * @return Iterator which contains all database mapping objects.
 */
- (NSEnumerator *)orderedDatabaseMappingDescriptors;

@end
